<?php $__env->startSection('content'); ?>
    <div class="container">
       <div class="row">
          <div class="col-md-12">
          <div class="panel panel-default">
        <div class="panel-head container-fluid" style="margin-top: 10px;">
       <a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-primary">Tambah Produk</a>
      <div class="pull-right">
          <br>
   <h2>Data produk</h2>
  </div>
  </div>
   <div class="panel-body">
     <table class="table table-striped">
      <thead>
       <tr>
        <th>No</th>
        
         <th>Kategori</th>
         
         <th>Dibuat Pada</th>
         <th>Diedit Pada</th>
     <th colspan="3" style="text-align:center;">Aksi</th>
    </tr>
   </thead>
<tbody>
   <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
             <td><?php echo e($i+1); ?></td>
             <td><?php echo e($p->nama); ?></td>
             
             
             <td><?php echo e($p->created_at); ?></td>
             <td><?php echo e($p->updated_at); ?></td>
             
             <td><a class="btn btn-success" href="<?php echo e(route('kategori.edit',$p->id)); ?>"> Edit</a></td>
      <td>
      <form method="post"action="<?php echo e(route('kategori.destroy',$p->id)); ?>">
          <?php echo e(csrf_field()); ?>

      <input type="hidden"name="_method" value="DELETE">
           <button class="btn btn-danger" type="submit">Hapus</button>
       </form>
   </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
 </div>
</div>
</div>
</div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_IFA\resources\views/kategori/index.blade.php ENDPATH**/ ?>